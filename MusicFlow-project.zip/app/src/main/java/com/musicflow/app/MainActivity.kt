package com.musicflow.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.res.ColorStateList

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 15, 24)
    private val panel = Color.rgb(24, 29, 43)
    private val accent = Color.rgb(122, 92, 255)
    private val white = Color.rgb(245, 246, 255)
    private val muted = Color.rgb(165, 171, 192)
    private val songs = mutableListOf<Song>()
    private var player: MediaPlayer? = null
    private var current = -1
    private lateinit var songList: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var playButton: Button
    private lateinit var status: TextView

    data class Song(val id: Long, val title: String, val artist: String, val uri: Uri)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        requestAudioPermission()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(28), dp(20), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = text("♫  MUSICFLOW", 14f, accent, true)
        content.addView(brand)
        val heading = text("Your sound.\nYour world.", 31f, white, true)
        heading.setPadding(0, dp(12), 0, dp(8))
        content.addView(heading)
        content.addView(text("A simple music player for your phone.", 14f, muted))
        val search = EditText(this).apply {
            hint = "Search your music"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            singleLine = true
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(panel, 16)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(48))
        searchParams.topMargin = dp(20)
        content.addView(search, searchParams)
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(22), 0, dp(12))
        }
        section.addView(text("Your library", 21f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = Button(this).apply {
            text = "SCAN"
            textSize = 11f
            setTextColor(white)
            backgroundTintList = ColorStateList.valueOf(accent)
            setOnClickListener { loadSongs() }
        }
        section.addView(refresh)
        content.addView(section)
        status = text("Looking for music on your device…", 13f, muted)
        status.setPadding(0, dp(8), 0, dp(12))
        content.addView(status)
        songList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(songList)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(panel, 18)
        }
        nowTitle = text("Choose a song to begin", 15f, white, true)
        playerCard.addView(nowTitle)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val previous = controlButton("⏮")
        previous.setOnClickListener { playAt((current - 1).coerceAtLeast(0)) }
        playButton = controlButton("▶")
        playButton.setOnClickListener { togglePlayback() }
        val next = controlButton("⏭")
        next.setOnClickListener { if (songs.isNotEmpty()) playAt((current + 1) % songs.size) }
        controls.addView(previous, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(playButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(next, LinearLayout.LayoutParams(0, dp(48), 1f))
        playerCard.addView(controls)
        root.addView(playerCard)
        setContentView(root)

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderSongs(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun controlButton(label: String) = Button(this).apply {
        text = label
        textSize = 21f
        setTextColor(white)
        backgroundTintList = ColorStateList.valueOf(accent)
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), 10)
        } else loadSongs()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            status.text = "Allow audio access to show songs stored on your phone."
        }
    }

    private fun loadSongs() {
        songs.clear()
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        try {
            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val title = c.getString(titleCol) ?: "Unknown track"
                    val artist = c.getString(artistCol) ?: "Unknown artist"
                    songs.add(Song(id, title, artist, ContentUris.withAppendedId(collection, id)))
                }
            }
            status.text = if (songs.isEmpty()) "No songs found. Add audio files to your phone, then tap SCAN."
                         else "${songs.size} songs found on your device"
            renderSongs("")
        } catch (_: Exception) {
            status.text = "Couldn't read music. Check audio permission and tap SCAN."
        }
    }

    private fun renderSongs(filter: String) {
        if (!::songList.isInitialized) return
        songList.removeAllViews()
        val visible = songs.withIndex().filter {
            it.value.title.contains(filter, true) || it.value.artist.contains(filter, true)
        }
        if (visible.isEmpty() && songs.isNotEmpty()) {
            songList.addView(text("No matching tracks.", 14f, muted))
        }
        visible.forEach { indexed ->
            val i = indexed.index
            val song = indexed.value
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(panel, 14)
            }
            val disc = TextView(this).apply {
                text = "♫"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(white)
                background = rounded(accent, 12)
            }
            row.addView(disc, LinearLayout.LayoutParams(dp(44), dp(44)))
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(4), 0)
                addView(text(song.title, 14f, white, true))
                addView(text(song.artist, 12f, muted))
            }
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("▶", 16f, accent, true))
            row.setOnClickListener { playAt(i) }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = dp(8)
            songList.addView(row, params)
        }
    }

    private fun playAt(index: Int) {
        if (index !in songs.indices) return
        try {
            player?.release()
            current = index
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, songs[index].uri)
                setOnCompletionListener {
                    if (songs.isNotEmpty()) playAt((current + 1) % songs.size)
                }
                prepare()
                start()
            }
            nowTitle.text = "${songs[index].title}\n${songs[index].artist}"
            playButton.text = "Ⅱ"
        } catch (_: Exception) {
            nowTitle.text = "Couldn't play this track"
            playButton.text = "▶"
        }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            if (songs.isNotEmpty()) playAt(if (current >= 0) current else 0)
            return
        }
        if (p.isPlaying) {
            p.pause()
            playButton.text = "▶"
        } else {
            p.start()
            playButton.text = "Ⅱ"
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
